Thanks to the following contributors:

    Chris Hoffman (3):
          Add new keywoards from, to, and do
          Highlight the - in negative integers
          Add here regex highlighting, increase fold level for here docs

    Karl Guertin (1):
          Cakefiles are coffeescript

    Simon Lipp (1):
          Trailing spaces are not error on lines containing only spaces

And thanks to anyone who files or has filed a bug report.
