vim-rabl
========

Treat RABL files as ruby files, with a little extra sugar for RABL-specific DSL methods.